# Foundation Bundle Structure

This document explains the layout and contents of the BPSR Combat Foundation Bundle.

## Directory Layout

```
foundation_staging/
├── refs/                          # Reference materials
│   ├── bpsr_packet_structure.png  # Visual packet structure diagram
│   ├── message.txt                # Example decoded protobuf payload
│   ├── exemplars/                 # Method 0x2E hex dumps
│   │   ├── 0x0000000063335342__m46__idx0__raw.hex.txt
│   │   ├── 0x0000000063335342__m46__idx1__raw.hex.txt
│   │   ├── 0x0000000063335342__m46__idx2__raw.hex.txt
│   │   ├── 0x0000000063335342__m46__idx3__raw.hex.txt
│   │   └── 0x0000000063335342__m46__idx4__raw.hex.txt
│   └── rust_reference/            # Original Rust implementation
│       ├── README.md              # Detailed architecture documentation
│       ├── main.rs                # Tauri app entry point
│       ├── lib.rs                 # Command bindings and WinDivert setup
│       ├── live_main.rs           # UI bridge and message dispatch
│       ├── packet_capture.rs      # WinDivert capture and TCP reassembly
│       └── packet_process.rs      # Frame parsing and zstd decompression
├── schema/                        # Protobuf schema artifacts
│   └── descriptor_tradecenter.pb # Trade-focused descriptor
├── captures/                      # Training and test data
│   ├── training/                 # Training captures
│   │   ├── s2c_training_dummy.bin
│   │   └── s2c_training_dummy_full.bin
│   └── streams_sample/            # Sample TCP streams (20 files)
│       ├── fwd_127.0.0.1_64820__127.0.0.1_64819.bin
│       ├── fwd_127.0.0.1_64822__127.0.0.1_64821.bin
│       └── ... (18 more stream files)
├── py/                           # Python implementation
│   ├── decoder/                  # Core decoder package
│   │   ├── __init__.py           # Package documentation
│   │   ├── framing.py            # Frame parsing and TCP reassembly
│   │   ├── combat_decode.py      # Combat message decoder
│   │   ├── combat_reduce.py      # DPS/damage aggregation
│   │   ├── codec_tests.py        # Unit tests
│   │   ├── bpsr_sniffer_reference.py  # Production decoder reference
│   │   └── decode_exchange_reference.py # Descriptor-based decoder
│   ├── cli/                      # Command-line utilities
│   │   ├── bpsr_decode_combat.py # Main decoder CLI
│   │   ├── bpsr_dps_reduce.py    # DPS analysis tool
│   │   └── bpsr_compare.py       # Decoder comparison tool
│   └── requirements.txt          # Python dependencies
├── docs/                         # Documentation
│   ├── STRUCTURE.md              # This file
│   ├── DECODER_GUIDE.md          # How to use the decoders
│   └── COMBAT_OPCODES.md         # Known combat method IDs
├── MANIFEST.json                 # File inventory and checksums
└── BUILD_NOTES.md               # Build process documentation
```

## Key Components

### Reference Materials (`refs/`)

- **`bpsr_packet_structure.png`**: Visual diagram showing TCP frame structure, fragment headers, and protobuf payload nesting
- **`message.txt`**: Example decoded protobuf payload from live capture
- **`exemplars/`**: Hex dumps of method 0x2E (0x46 decimal) packets for testing
- **`rust_reference/`**: Complete Rust implementation for cross-reference

### Training Data (`captures/`)

- **`training/`**: Short and full training captures for development
- **`streams_sample/`**: First 20 TCP stream files from live captures (out of 321 total)

### Python Implementation (`py/`)

- **`decoder/`**: Core package with frame parsing, combat decoding, and data reduction
- **`cli/`**: Command-line tools for processing captures and analyzing results
- **`requirements.txt`**: Minimal dependencies (protobuf, zstandard, rich)

### Schema (`schema/`)

- **`descriptor_tradecenter.pb`**: Compiled protobuf descriptor (trade-focused, not combat)

## Usage Patterns

### Development Workflow

1. **Study References**: Start with `refs/bpsr_packet_structure.png` and `refs/rust_reference/README.md`
2. **Test with Training Data**: Use `captures/training/` files for initial development
3. **Validate with Streams**: Test with `captures/streams_sample/` for real-world data
4. **Compare Implementations**: Use `py/decoder/*_reference.py` as working examples

### CLI Usage

```bash
# Decode combat packets
python py/cli/bpsr_decode_combat.py captures/training/s2c_training_dummy_full.bin

# Analyze DPS data
python py/cli/bpsr_dps_reduce.py combat_output.json

# Compare decoder outputs
python py/cli/bpsr_compare.py decoder1_output.json decoder2_output.json
```

## Known Limitations

1. **Schema Gap**: Only trade-focused protobuf descriptor available; combat schema needs reverse-engineering
2. **Limited Streams**: Only 20 of 321 stream files included to keep bundle size reasonable
3. **Placeholder Decoding**: Combat message decoding is scaffolded but needs protobuf schema completion

## Next Steps

1. **Reverse-engineer combat protobuf schema** from exemplar payloads
2. **Implement full protobuf decoding** in `combat_decode.py`
3. **Add live capture support** for real-time packet processing
4. **Extend DPS analysis** with more sophisticated metrics
