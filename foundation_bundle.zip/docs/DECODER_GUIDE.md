# BPSR Decoder Usage Guide

This guide explains how to use the BPSR combat decoders included in the foundation bundle.

## Overview

The foundation bundle includes two reference decoder implementations:

1. **`bpsr_sniffer_reference.py`**: Production-ready decoder with TCP reassembly, framing, and zstd decompression
2. **`decode_exchange_reference.py`**: Descriptor-based decoder using protobuf descriptors

## Quick Start

### 1. Install Dependencies

```bash
pip install -r py/requirements.txt
```

### 2. Basic Usage

```python
from py.decoder.framing import extract_fragments, is_combat_packet
from py.decoder.combat_decode import CombatDecoder

# Load a capture file
with open('captures/training/s2c_training_dummy_full.bin', 'rb') as f:
    data = f.read()

# Extract and decode combat messages
decoder = CombatDecoder()
for service_uid, stub_id, method_id, frag_type, payload in extract_fragments(data):
    if is_combat_packet(service_uid):
        decoded = decoder.decode_combat_message(method_id, payload)
        if decoded:
            print(f"Method 0x{method_id:02X}: {decoded['message_type']}")
```

### 3. Using the CLI Tools

```bash
# Decode combat packets
python py/cli/bpsr_decode_combat.py captures/training/s2c_training_dummy_full.bin

# Analyze DPS data (requires JSON input)
python py/cli/bpsr_dps_reduce.py combat_output.json

# Compare decoder outputs
python py/cli/bpsr_compare.py decoder1_output.json decoder2_output.json
```

## Reference Decoders

### BPSR Sniffer Reference

The `bpsr_sniffer_reference.py` is a complete implementation that includes:

- **TCP Reassembly**: Handles fragmented TCP streams
- **Frame Parsing**: Extracts length-prefixed BPSR frames
- **Zstd Decompression**: Handles compressed payloads
- **Protobuf Decoding**: Decodes known message types

Key classes:
- `BPSRPacketProcessor`: Main packet processor
- `BPSRSniffer`: Live packet capture (Windows only)

Example:
```python
from py.decoder.bpsr_sniffer_reference import BPSRPacketProcessor

processor = BPSRPacketProcessor()
for pkt, payload in processor.process_bytes(data):
    print(f"Packet: {pkt}, Payload length: {len(payload)}")
```

### Exchange Decoder Reference

The `decode_exchange_reference.py` demonstrates descriptor-based decoding:

- **Descriptor Loading**: Loads protobuf descriptors from `.pb` files
- **Message Enumeration**: Discovers available message types
- **Brute-force Decoding**: Attempts to decode with all known message types

Example:
```python
from py.decoder.decode_exchange_reference import load_factory_and_names, decode_with_factory

factory, names = load_factory_and_names('schema/descriptor_tradecenter.pb')
decoded = decode_with_factory(factory, names, payload)
```

## Frame Structure

BPSR packets use a specific frame structure:

```
+------------------+
| frag_len (4B BE) |  Total frame length
+------------------+
| packet_type (2B) |  High bit = zstd flag, low 15 bits = fragment type
+------------------+
| service_uid (8B) |  Service identifier (combat = 0x0000000063335342)
+------------------+
| stub_id (4B)     |  Stub/handler ID (unused)
+------------------+
| method_id (4B)   |  Maps to protobuf message type
+------------------+
| payload (var)    |  Protobuf-encoded body (may be zstd-compressed)
+------------------+
```

## Combat Message Types

Known combat message types (method IDs):

| Method ID | Message Type | Description |
|-----------|--------------|-------------|
| 0x2E | SyncNearEntities | Entities entering/leaving AOI |
| 0x46 | SyncContainerData | Detailed player snapshot |
| 0x47 | SyncContainerDirtyData | Lightweight player update |
| 0x48 | SyncServerTime | Server heartbeat |
| 0x49 | SyncToMeDeltaInfo | Local player identification |
| 0x4A | SyncNearDeltaInfo | Entity-to-entity action deltas |

## Testing

Run the unit tests to verify decoder functionality:

```bash
python -m pytest py/decoder/codec_tests.py -v
```

The tests cover:
- Frame header parsing
- Fragment extraction
- Combat message decoding
- DPS data reduction

## Troubleshooting

### Common Issues

1. **Missing Dependencies**: Install with `pip install -r py/requirements.txt`
2. **Invalid Frame Data**: Ensure input is properly reassembled TCP stream
3. **Unknown Message Types**: Check method ID against known combat types
4. **Decompression Errors**: Verify zstd library is installed

### Debug Mode

Enable verbose logging for troubleshooting:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Or use CLI with --verbose flag
python py/cli/bpsr_decode_combat.py input.bin --verbose
```

### Validation

Use the comparison tool to validate decoder outputs:

```bash
python py/cli/bpsr_compare.py reference_output.json new_output.json
```

## Next Steps

1. **Complete Protobuf Schema**: Reverse-engineer combat message definitions
2. **Extend Message Types**: Add support for additional combat messages
3. **Live Capture**: Implement real-time packet processing
4. **Performance Optimization**: Optimize for high-throughput scenarios
