# BPSR Combat Opcodes Reference

This document catalogs known combat-related method IDs and message types for BPSR packet decoding.

## Service UID

All combat packets use the service UID: `0x0000000063335342`

This identifier appears in the frame header and is used to filter combat traffic from other game systems.

## Combat Message Types

### Entity Synchronization

| Method ID | Hex | Message Type | Description |
|-----------|-----|-------------|-------------|
| 46 | 0x2E | SyncNearEntities | Entities entering/leaving Area of Interest (AOI) |
| 70 | 0x46 | SyncContainerData | Detailed snapshot of local player |
| 71 | 0x47 | SyncContainerDirtyData | Lightweight player update (HP, name, class) |

### Time Synchronization

| Method ID | Hex | Message Type | Description |
|-----------|-----|-------------|-------------|
| 72 | 0x48 | SyncServerTime | Periodic heartbeat with server timestamp |

### Combat Events

| Method ID | Hex | Message Type | Description |
|-----------|-----|-------------|-------------|
| 73 | 0x49 | SyncToMeDeltaInfo | Identifies the UID of the local player |
| 74 | 0x4A | SyncNearDeltaInfo | Entity-to-entity action deltas (damage/heal events) |

## Fragment Types

BPSR uses different fragment types for different message categories:

| Fragment Type | Value | Description |
|---------------|-------|-------------|
| None | 0 | No fragment type |
| Call | 1 | RPC call |
| Notify | 2 | Notification message |
| Return | 3 | RPC return |
| Echo | 4 | Echo message |
| FrameUp | 5 | Frame up |
| FrameDown | 6 | Frame down (nested frames) |

## Compression

Frames may be compressed using zstd compression. The compression flag is indicated by the high bit of the `packet_type` field:

- `packet_type & 0x8000 != 0`: Frame is zstd-compressed
- `packet_type & 0x7FFF`: Actual fragment type

## Example Frame Structure

```
Offset | Size | Field      | Example Value | Description
-------|------|------------|---------------|------------
0-3    | 4B   | frag_len   | 0x00000078    | Total frame length (120 bytes)
4-5    | 2B   | packet_type| 0x0006        | Fragment type 6 (FrameDown)
6-13   | 8B   | service_uid| 0x0000000063335342 | Combat service UID
14-17  | 4B   | stub_id    | 0x00000000    | Stub ID (unused)
18-21  | 4B   | method_id  | 0x0000002E    | Method ID (SyncNearEntities)
22+    | var  | payload    | [protobuf]    | Protobuf-encoded message
```

## Combat Event Processing

### Damage Events

Damage events are typically found in `SyncNearDeltaInfo` messages (method ID 0x4A). These contain:

- Source entity ID
- Target entity ID  
- Damage amount
- Event timestamp
- Additional metadata

### Entity Updates

Entity synchronization messages (`SyncNearEntities`, `SyncContainerData`) contain:

- Entity ID and name
- Position and orientation
- Health and status information
- Class and level data
- Guild and housing information

## Validation

To validate combat packet decoding:

1. **Check Service UID**: Ensure `service_uid == 0x0000000063335342`
2. **Verify Method ID**: Check against known combat method IDs
3. **Parse Fragment Type**: Handle different fragment types appropriately
4. **Decompress if Needed**: Check compression flag and decompress with zstd

## Exemplar Data

The foundation bundle includes exemplar hex dumps for method 0x2E (0x46 decimal):

- `refs/exemplars/0x0000000063335342__m46__idx0__raw.hex.txt`
- `refs/exemplars/0x0000000063335342__m46__idx1__raw.hex.txt`
- `refs/exemplars/0x0000000063335342__m46__idx2__raw.hex.txt`
- `refs/exemplars/0x0000000063335342__m46__idx3__raw.hex.txt`
- `refs/exemplars/0x0000000063335342__m46__idx4__raw.hex.txt`

These can be used for testing and validation of the decoder implementation.

## Implementation Notes

### Python Decoder

```python
from py.decoder.framing import parse_frame_header, is_combat_packet
from py.decoder.combat_decode import CombatDecoder

# Parse frame header
frag_len, packet_type, service_uid, stub_id, method_id, payload = parse_frame_header(data)

# Check if combat packet
if is_combat_packet(service_uid):
    # Decode combat message
    decoder = CombatDecoder()
    decoded = decoder.decode_combat_message(method_id, payload)
```

### Rust Reference

The Rust implementation in `refs/rust_reference/` provides the authoritative reference for:

- Frame parsing logic
- Compression handling
- Message type mapping
- Error handling

## Future Extensions

As more combat message types are discovered, this reference should be updated with:

- New method IDs and message types
- Additional fragment types
- Extended payload structures
- New compression methods
