#!/usr/bin/env python3
"""
BPSR Combat Decoder CLI
======================

Command-line interface for decoding BPSR combat packets from capture files
or live streams. This tool processes TCP streams, extracts BPSR frames,
and decodes combat-specific protobuf messages.

Usage:
    python bpsr_decode_combat.py <input_file> [options]
    python bpsr_decode_combat.py --live [options]
"""

import argparse
import sys
import logging
from pathlib import Path
from typing import Iterator, Tuple

try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress
    HAVE_RICH = True
except ImportError:
    HAVE_RICH = False

from ..decoder.framing import extract_fragments, is_combat_packet
from ..decoder.combat_decode import CombatDecoder


def setup_logging(verbose: bool = False) -> None:
    """Setup logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def process_file(input_path: Path, verbose: bool = False) -> Iterator[Tuple[int, dict]]:
    """
    Process a capture file and yield decoded combat messages.
    
    Args:
        input_path: Path to input file
        verbose: Enable verbose logging
        
    Yields:
        (method_id, decoded_message) tuples
    """
    decoder = CombatDecoder()
    
    with open(input_path, 'rb') as f:
        data = f.read()
    
    # Extract fragments from the data
    for service_uid, stub_id, method_id, frag_type, payload in extract_fragments(data):
        if not is_combat_packet(service_uid):
            if verbose:
                logging.debug(f"Skipping non-combat packet: service_uid=0x{service_uid:016X}")
            continue
        
        # Decode combat message
        decoded = decoder.decode_combat_message(method_id, payload)
        if decoded:
            yield method_id, decoded


def print_results(results: Iterator[Tuple[int, dict]], use_rich: bool = True) -> None:
    """Print decoded results in a formatted table."""
    if not HAVE_RICH or not use_rich:
        # Simple text output
        for method_id, decoded in results:
            print(f"Method 0x{method_id:02X}: {decoded['message_type']}")
            print(f"  Payload: {decoded['raw_payload'][:64]}...")
            print()
        return
    
    # Rich table output
    console = Console()
    table = Table(title="BPSR Combat Messages")
    table.add_column("Method ID", style="cyan")
    table.add_column("Message Type", style="green")
    table.add_column("Payload Preview", style="yellow")
    
    for method_id, decoded in results:
        payload_preview = decoded['raw_payload'][:32] + "..." if len(decoded['raw_payload']) > 32 else decoded['raw_payload']
        table.add_row(
            f"0x{method_id:02X}",
            decoded['message_type'],
            payload_preview
        )
    
    console.print(table)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Decode BPSR combat packets from capture files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python bpsr_decode_combat.py capture.bin
  python bpsr_decode_combat.py capture.bin --verbose
  python bpsr_decode_combat.py capture.bin --output results.json
        """
    )
    
    parser.add_argument(
        'input_file',
        type=Path,
        help='Input capture file to process'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    parser.add_argument(
        '--output', '-o',
        type=Path,
        help='Output file for results (JSON format)'
    )
    parser.add_argument(
        '--no-rich',
        action='store_true',
        help='Disable rich formatting (use plain text)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    # Check input file
    if not args.input_file.exists():
        logging.error(f"Input file not found: {args.input_file}")
        sys.exit(1)
    
    try:
        # Process file
        results = process_file(args.input_file, args.verbose)
        
        if args.output:
            # Save to file
            import json
            output_data = []
            for method_id, decoded in results:
                output_data.append({
                    'method_id': f"0x{method_id:02X}",
                    'decoded': decoded
                })
            
            with open(args.output, 'w') as f:
                json.dump(output_data, f, indent=2)
            
            logging.info(f"Results saved to {args.output}")
        else:
            # Print to console
            print_results(results, use_rich=not args.no_rich)
    
    except Exception as e:
        logging.error(f"Failed to process file: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
