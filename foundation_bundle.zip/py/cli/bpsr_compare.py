#!/usr/bin/env python3
"""
BPSR Decoder Comparison Tool
============================

Command-line tool for comparing outputs from different BPSR decoders.
This tool helps validate decoder implementations by comparing their
outputs on the same input data.

Usage:
    python bpsr_compare.py <decoder1_output> <decoder2_output> [options]
"""

import argparse
import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    HAVE_RICH = True
except ImportError:
    HAVE_RICH = False


@dataclass
class ComparisonResult:
    """Result of comparing two decoder outputs."""
    identical: bool
    total_messages: int
    matching_messages: int
    differences: List[Dict[str, Any]]
    summary: str


def setup_logging(verbose: bool = False) -> None:
    """Setup logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def load_decoder_output(file_path: Path) -> List[Dict[str, Any]]:
    """
    Load decoder output from file.
    
    Args:
        file_path: Path to decoder output file
        
    Returns:
        List of decoded messages
    """
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    # Handle different output formats
    if isinstance(data, list):
        return data
    elif isinstance(data, dict) and 'messages' in data:
        return data['messages']
    else:
        raise ValueError(f"Invalid decoder output format in {file_path}")


def compare_messages(messages1: List[Dict[str, Any]], messages2: List[Dict[str, Any]]) -> ComparisonResult:
    """
    Compare two sets of decoded messages.
    
    Args:
        messages1: First decoder output
        messages2: Second decoder output
        
    Returns:
        Comparison result
    """
    differences = []
    matching_count = 0
    
    # Compare message counts
    if len(messages1) != len(messages2):
        differences.append({
            'type': 'count_mismatch',
            'decoder1_count': len(messages1),
            'decoder2_count': len(messages2)
        })
    
    # Compare individual messages
    min_count = min(len(messages1), len(messages2))
    for i in range(min_count):
        msg1 = messages1[i]
        msg2 = messages2[i]
        
        # Compare message structure
        if msg1.get('method_id') != msg2.get('method_id'):
            differences.append({
                'type': 'method_id_mismatch',
                'index': i,
                'decoder1_method_id': msg1.get('method_id'),
                'decoder2_method_id': msg2.get('method_id')
            })
        elif msg1.get('message_type') != msg2.get('message_type'):
            differences.append({
                'type': 'message_type_mismatch',
                'index': i,
                'decoder1_type': msg1.get('message_type'),
                'decoder2_type': msg2.get('message_type')
            })
        else:
            matching_count += 1
    
    # Generate summary
    if not differences:
        summary = f"All {matching_count} messages match perfectly"
    else:
        summary = f"{matching_count}/{min_count} messages match, {len(differences)} differences found"
    
    return ComparisonResult(
        identical=len(differences) == 0,
        total_messages=min_count,
        matching_messages=matching_count,
        differences=differences,
        summary=summary
    )


def print_comparison_result(result: ComparisonResult, use_rich: bool = True) -> None:
    """Print comparison results."""
    if not HAVE_RICH or not use_rich:
        # Simple text output
        print(f"Comparison Result: {result.summary}")
        print(f"Total messages: {result.total_messages}")
        print(f"Matching messages: {result.matching_messages}")
        print(f"Differences: {len(result.differences)}")
        
        for diff in result.differences:
            print(f"  - {diff['type']}: {diff}")
        return
    
    # Rich output
    console = Console()
    
    # Create summary panel
    status_color = "green" if result.identical else "red"
    status_text = "✓ IDENTICAL" if result.identical else "✗ DIFFERENCES FOUND"
    
    summary_text = f"""
{status_text}

{result.summary}
Total Messages: {result.total_messages}
Matching: {result.matching_messages}
Differences: {len(result.differences)}
    """.strip()
    
    console.print(Panel(summary_text, title="Comparison Summary", border_style=status_color))
    
    # Show differences if any
    if result.differences:
        table = Table(title="Differences Found")
        table.add_column("Type", style="red")
        table.add_column("Index", style="yellow")
        table.add_column("Decoder 1", style="cyan")
        table.add_column("Decoder 2", style="magenta")
        
        for diff in result.differences:
            table.add_row(
                diff['type'],
                str(diff.get('index', 'N/A')),
                str(diff.get('decoder1_method_id', diff.get('decoder1_type', 'N/A'))),
                str(diff.get('decoder2_method_id', diff.get('decoder2_type', 'N/A')))
            )
        
        console.print(table)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Compare outputs from different BPSR decoders",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python bpsr_compare.py decoder1_output.json decoder2_output.json
  python bpsr_compare.py decoder1_output.json decoder2_output.json --verbose
  python bpsr_compare.py decoder1_output.json decoder2_output.json --output comparison.json
        """
    )
    
    parser.add_argument(
        'decoder1_output',
        type=Path,
        help='First decoder output file (JSON)'
    )
    parser.add_argument(
        'decoder2_output',
        type=Path,
        help='Second decoder output file (JSON)'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    parser.add_argument(
        '--output', '-o',
        type=Path,
        help='Output file for comparison results (JSON format)'
    )
    parser.add_argument(
        '--no-rich',
        action='store_true',
        help='Disable rich formatting (use plain text)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    # Check input files
    for file_path in [args.decoder1_output, args.decoder2_output]:
        if not file_path.exists():
            logging.error(f"Input file not found: {file_path}")
            sys.exit(1)
    
    try:
        # Load decoder outputs
        messages1 = load_decoder_output(args.decoder1_output)
        messages2 = load_decoder_output(args.decoder2_output)
        
        logging.info(f"Loaded {len(messages1)} messages from decoder 1")
        logging.info(f"Loaded {len(messages2)} messages from decoder 2")
        
        # Compare messages
        result = compare_messages(messages1, messages2)
        
        if args.output:
            # Save comparison results
            output_data = {
                'identical': result.identical,
                'total_messages': result.total_messages,
                'matching_messages': result.matching_messages,
                'differences': result.differences,
                'summary': result.summary
            }
            
            with open(args.output, 'w') as f:
                json.dump(output_data, f, indent=2)
            
            logging.info(f"Comparison results saved to {args.output}")
        else:
            # Print to console
            print_comparison_result(result, use_rich=not args.no_rich)
        
        # Exit with appropriate code
        sys.exit(0 if result.identical else 1)
    
    except Exception as e:
        logging.error(f"Failed to compare files: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
