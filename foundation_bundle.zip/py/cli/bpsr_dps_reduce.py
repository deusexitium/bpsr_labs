#!/usr/bin/env python3
"""
BPSR DPS Reduction Tool
========================

Command-line tool for aggregating and analyzing DPS data from BPSR combat
packets. This tool processes decoded combat messages and calculates
damage-per-second statistics, encounter summaries, and player performance metrics.

Usage:
    python bpsr_dps_reduce.py <input_file> [options]
    python bpsr_dps_reduce.py --live [options]
"""

import argparse
import sys
import json
import logging
from pathlib import Path
from typing import List, Dict, Any

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    HAVE_RICH = True
except ImportError:
    HAVE_RICH = False

from ..decoder.combat_reduce import CombatReducer, EncounterStats


def setup_logging(verbose: bool = False) -> None:
    """Setup logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def load_combat_data(input_path: Path) -> List[Dict[str, Any]]:
    """
    Load combat data from input file.
    
    Args:
        input_path: Path to input JSON file
        
    Returns:
        List of combat message dictionaries
    """
    with open(input_path, 'r') as f:
        data = json.load(f)
    
    # Handle different input formats
    if isinstance(data, list):
        return data
    elif isinstance(data, dict) and 'messages' in data:
        return data['messages']
    else:
        raise ValueError("Invalid input format")


def simulate_combat_events(messages: List[Dict[str, Any]]) -> List[EncounterStats]:
    """
    Simulate combat events from decoded messages.
    
    This is a placeholder function that would normally extract damage events
    from protobuf messages. For now, it creates mock events for demonstration.
    
    Args:
        messages: List of decoded combat messages
        
    Returns:
        List of encounter statistics
    """
    from ..decoder.combat_decode import CombatEvent
    import time
    
    reducer = CombatReducer()
    
    # Simulate some damage events (in real implementation, these would be
    # extracted from the protobuf messages)
    mock_events = [
        CombatEvent("damage", 123, 456, 1000, time.time(), {}),
        CombatEvent("damage", 123, 456, 1500, time.time() + 1, {}),
        CombatEvent("damage", 789, 456, 800, time.time() + 2, {}),
        CombatEvent("damage", 123, 456, 1200, time.time() + 3, {}),
    ]
    
    # Process events
    for event in mock_events:
        reducer.process_event(event)
    
    # End encounter
    completed = reducer.end_encounter()
    
    return [completed] if completed else []


def print_encounter_summary(encounters: List[EncounterStats], use_rich: bool = True) -> None:
    """Print encounter summary statistics."""
    if not encounters:
        print("No encounters found.")
        return
    
    if not HAVE_RICH or not use_rich:
        # Simple text output
        for i, encounter in enumerate(encounters):
            print(f"Encounter {i + 1}:")
            print(f"  Duration: {encounter.duration:.2f}s")
            print(f"  Total Damage: {encounter.total_damage}")
            print(f"  DPS: {encounter.get_dps():.2f}")
            print()
        return
    
    # Rich output
    console = Console()
    
    for i, encounter in enumerate(encounters):
        # Create summary panel
        summary_text = f"""
Duration: {encounter.duration:.2f}s
Total Damage: {encounter.total_damage:,}
DPS: {encounter.get_dps():.2f}
Events: {len(encounter.events)}
        """.strip()
        
        console.print(Panel(summary_text, title=f"Encounter {i + 1} Summary"))
        
        # Create damage dealers table
        if encounter.damage_by_source:
            table = Table(title="Top Damage Dealers")
            table.add_column("Entity ID", style="cyan")
            table.add_column("Total Damage", style="green")
            table.add_column("Hit Count", style="yellow")
            table.add_column("Avg Hit", style="magenta")
            table.add_column("Max Hit", style="red")
            
            top_dealers = sorted(
                encounter.damage_by_source.items(),
                key=lambda x: x[1].total_damage,
                reverse=True
            )[:10]
            
            for entity_id, stats in top_dealers:
                table.add_row(
                    str(entity_id),
                    f"{stats.total_damage:,}",
                    str(stats.damage_count),
                    f"{stats.avg_damage:.1f}",
                    f"{stats.max_hit:,}"
                )
            
            console.print(table)
        
        print()  # Add spacing between encounters


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Analyze DPS data from BPSR combat packets",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python bpsr_dps_reduce.py combat_data.json
  python bpsr_dps_reduce.py combat_data.json --verbose
  python bpsr_dps_reduce.py combat_data.json --output summary.json
        """
    )
    
    parser.add_argument(
        'input_file',
        type=Path,
        help='Input JSON file with combat data'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    parser.add_argument(
        '--output', '-o',
        type=Path,
        help='Output file for summary (JSON format)'
    )
    parser.add_argument(
        '--no-rich',
        action='store_true',
        help='Disable rich formatting (use plain text)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    # Check input file
    if not args.input_file.exists():
        logging.error(f"Input file not found: {args.input_file}")
        sys.exit(1)
    
    try:
        # Load combat data
        messages = load_combat_data(args.input_file)
        logging.info(f"Loaded {len(messages)} combat messages")
        
        # Simulate combat events (placeholder for real protobuf parsing)
        encounters = simulate_combat_events(messages)
        logging.info(f"Processed {len(encounters)} encounters")
        
        if args.output:
            # Save summary to file
            summary_data = []
            for encounter in encounters:
                summary_data.append({
                    'duration': encounter.duration,
                    'total_damage': encounter.total_damage,
                    'dps': encounter.get_dps(),
                    'damage_by_source': {
                        str(k): {
                            'total_damage': v.total_damage,
                            'damage_count': v.damage_count,
                            'avg_damage': v.avg_damage,
                            'max_hit': v.max_hit,
                            'min_hit': v.min_hit
                        } for k, v in encounter.damage_by_source.items()
                    }
                })
            
            with open(args.output, 'w') as f:
                json.dump(summary_data, f, indent=2)
            
            logging.info(f"Summary saved to {args.output}")
        else:
            # Print to console
            print_encounter_summary(encounters, use_rich=not args.no_rich)
    
    except Exception as e:
        logging.error(f"Failed to process file: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
