"""
BPSR Decoder Unit Tests
=======================

This module contains unit tests for the BPSR decoder components.
It tests frame parsing, combat message decoding, and data reduction.

Run with: python -m pytest py/decoder/codec_tests.py
"""

import unittest
import struct
from typing import List

from .framing import parse_frame_header, decompress_payload, extract_fragments, is_combat_packet
from .combat_decode import CombatDecoder
from .combat_reduce import CombatReducer, CombatEvent


class TestFrameParsing(unittest.TestCase):
    """Test frame parsing functionality."""
    
    def test_parse_frame_header(self):
        """Test parsing of frame headers."""
        # Create a test frame
        service_uid = 0x0000000063335342
        stub_id = 0x00000000
        method_id = 0x0000002E
        payload = b"test payload"
        
        # Build frame header
        header = struct.pack('>I', 22 + len(payload))  # frag_len
        header += struct.pack('>H', 2)  # packet_type (Notify)
        header += struct.pack('>Q', service_uid)
        header += struct.pack('>I', stub_id)
        header += struct.pack('>I', method_id)
        header += payload
        
        # Parse header
        frag_len, packet_type, parsed_service_uid, parsed_stub_id, parsed_method_id, parsed_payload = parse_frame_header(header)
        
        self.assertEqual(frag_len, 22 + len(payload))
        self.assertEqual(packet_type, 2)
        self.assertEqual(parsed_service_uid, service_uid)
        self.assertEqual(parsed_stub_id, stub_id)
        self.assertEqual(parsed_method_id, method_id)
        self.assertEqual(parsed_payload, payload)
    
    def test_is_combat_packet(self):
        """Test combat packet identification."""
        combat_uid = 0x0000000063335342
        other_uid = 0x0000000012345678
        
        self.assertTrue(is_combat_packet(combat_uid))
        self.assertFalse(is_combat_packet(other_uid))
    
    def test_extract_fragments(self):
        """Test fragment extraction."""
        # Create test fragments
        fragments = []
        for i in range(3):
            service_uid = 0x0000000063335342
            stub_id = 0x00000000
            method_id = 0x0000002E + i
            payload = f"test payload {i}".encode()
            
            # Build frame
            header = struct.pack('>I', 22 + len(payload))
            header += struct.pack('>H', 2)  # Notify
            header += struct.pack('>Q', service_uid)
            header += struct.pack('>I', stub_id)
            header += struct.pack('>I', method_id)
            header += payload
            
            fragments.append(header)
        
        # Combine fragments
        combined = b''.join(fragments)
        
        # Extract fragments
        extracted = list(extract_fragments(combined))
        
        self.assertEqual(len(extracted), 3)
        for i, (service_uid, stub_id, method_id, frag_type, payload) in enumerate(extracted):
            self.assertEqual(service_uid, 0x0000000063335342)
            self.assertEqual(stub_id, 0x00000000)
            self.assertEqual(method_id, 0x0000002E + i)
            self.assertEqual(frag_type, 2)
            self.assertEqual(payload, f"test payload {i}".encode())


class TestCombatDecoder(unittest.TestCase):
    """Test combat message decoding."""
    
    def setUp(self):
        self.decoder = CombatDecoder()
    
    def test_decode_combat_message(self):
        """Test decoding of combat messages."""
        # Test known method IDs
        test_cases = [
            (0x2E, "SyncNearEntities"),
            (0x46, "SyncContainerData"),
            (0x47, "SyncContainerDirtyData"),
            (0x48, "SyncServerTime"),
            (0x49, "SyncToMeDeltaInfo"),
            (0x4A, "SyncNearDeltaInfo"),
        ]
        
        for method_id, expected_type in test_cases:
            payload = b"test payload"
            result = self.decoder.decode_combat_message(method_id, payload)
            
            self.assertIsNotNone(result)
            self.assertEqual(result["message_type"], expected_type)
            self.assertEqual(result["raw_payload"], payload.hex())
    
    def test_decode_unknown_message(self):
        """Test handling of unknown message types."""
        payload = b"test payload"
        result = self.decoder.decode_combat_message(0x9999, payload)
        
        self.assertIsNone(result)


class TestCombatReducer(unittest.TestCase):
    """Test combat data reduction."""
    
    def setUp(self):
        self.reducer = CombatReducer()
    
    def test_process_damage_event(self):
        """Test processing of damage events."""
        event = CombatEvent(
            event_type="damage",
            source_id=123,
            target_id=456,
            value=1000,
            timestamp=1000.0,
            metadata={}
        )
        
        self.reducer.process_event(event)
        
        # Check that encounter was started
        self.assertIsNotNone(self.reducer.current_encounter)
        self.assertEqual(self.reducer.current_encounter.total_damage, 1000)
        
        # Check damage stats
        self.assertIn(123, self.reducer.current_encounter.damage_by_source)
        self.assertIn(456, self.reducer.current_encounter.damage_by_target)
        
        source_stats = self.reducer.current_encounter.damage_by_source[123]
        self.assertEqual(source_stats.total_damage, 1000)
        self.assertEqual(source_stats.damage_count, 1)
        self.assertEqual(source_stats.max_hit, 1000)
        self.assertEqual(source_stats.min_hit, 1000)
    
    def test_end_encounter(self):
        """Test ending an encounter."""
        # Process some events
        event1 = CombatEvent("damage", 123, 456, 1000, 1000.0, {})
        event2 = CombatEvent("damage", 123, 456, 500, 1001.0, {})
        
        self.reducer.process_event(event1)
        self.reducer.process_event(event2)
        
        # End encounter
        completed = self.reducer.end_encounter()
        
        self.assertIsNotNone(completed)
        self.assertEqual(completed.total_damage, 1500)
        self.assertEqual(completed.duration, 1.0)
        self.assertIsNone(self.reducer.current_encounter)
    
    def test_top_damage_dealers(self):
        """Test getting top damage dealers."""
        # Process events from multiple sources
        events = [
            CombatEvent("damage", 123, 456, 1000, 1000.0, {}),
            CombatEvent("damage", 789, 456, 2000, 1001.0, {}),
            CombatEvent("damage", 123, 456, 500, 1002.0, {}),
        ]
        
        for event in events:
            self.reducer.process_event(event)
        
        # Get top dealers
        top_dealers = self.reducer.get_top_damage_dealers(2)
        
        self.assertEqual(len(top_dealers), 2)
        self.assertEqual(top_dealers[0][0], 789)  # Highest damage
        self.assertEqual(top_dealers[1][0], 123)  # Second highest


if __name__ == '__main__':
    unittest.main()
