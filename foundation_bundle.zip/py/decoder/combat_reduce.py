"""
BPSR Combat Data Reduction and Aggregation
===========================================

This module provides utilities for aggregating and reducing combat data
from BPSR packets. It handles DPS calculation, damage/heal tracking,
and encounter statistics.

Key functions:
- calculate_dps: Compute damage per second metrics
- aggregate_damage: Sum damage events by source/target
- track_encounter: Maintain encounter state and statistics
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict

from .combat_decode import CombatEvent


@dataclass
class DamageStats:
    """Damage statistics for an entity."""
    total_damage: int = 0
    damage_count: int = 0
    max_hit: int = 0
    min_hit: int = 0
    avg_damage: float = 0.0


@dataclass
class EncounterStats:
    """Statistics for a combat encounter."""
    start_time: float
    end_time: Optional[float] = None
    duration: float = 0.0
    total_damage: int = 0
    damage_by_source: Dict[int, DamageStats] = field(default_factory=dict)
    damage_by_target: Dict[int, DamageStats] = field(default_factory=dict)
    events: List[CombatEvent] = field(default_factory=list)
    
    def is_active(self) -> bool:
        """Check if encounter is currently active."""
        return self.end_time is None
    
    def get_dps(self) -> float:
        """Calculate overall DPS for the encounter."""
        if self.duration <= 0:
            return 0.0
        return self.total_damage / self.duration


class CombatReducer:
    """Reducer for aggregating combat data."""
    
    def __init__(self):
        self.current_encounter: Optional[EncounterStats] = None
        self.encounter_history: List[EncounterStats] = []
    
    def process_event(self, event: CombatEvent) -> None:
        """
        Process a combat event and update encounter statistics.
        
        Args:
            event: Combat event to process
        """
        # Start new encounter if none active
        if self.current_encounter is None:
            self.current_encounter = EncounterStats(start_time=event.timestamp)
        
        # Add event to current encounter
        self.current_encounter.events.append(event)
        
        # Update damage statistics
        if event.event_type == "damage":
            self._update_damage_stats(event)
    
    def _update_damage_stats(self, event: CombatEvent) -> None:
        """Update damage statistics for an event."""
        if self.current_encounter is None:
            return
        
        # Update total damage
        self.current_encounter.total_damage += event.value
        
        # Update source stats
        if event.source_id not in self.current_encounter.damage_by_source:
            self.current_encounter.damage_by_source[event.source_id] = DamageStats()
        
        source_stats = self.current_encounter.damage_by_source[event.source_id]
        source_stats.total_damage += event.value
        source_stats.damage_count += 1
        source_stats.max_hit = max(source_stats.max_hit, event.value)
        source_stats.min_hit = min(source_stats.min_hit, event.value) if source_stats.min_hit > 0 else event.value
        source_stats.avg_damage = source_stats.total_damage / source_stats.damage_count
        
        # Update target stats
        if event.target_id not in self.current_encounter.damage_by_target:
            self.current_encounter.damage_by_target[event.target_id] = DamageStats()
        
        target_stats = self.current_encounter.damage_by_target[event.target_id]
        target_stats.total_damage += event.value
        target_stats.damage_count += 1
        target_stats.max_hit = max(target_stats.max_hit, event.value)
        target_stats.min_hit = min(target_stats.min_hit, event.value) if target_stats.min_hit > 0 else event.value
        target_stats.avg_damage = target_stats.total_damage / target_stats.damage_count
    
    def end_encounter(self) -> Optional[EncounterStats]:
        """
        End the current encounter and return its statistics.
        
        Returns:
            Completed encounter statistics or None if no active encounter
        """
        if self.current_encounter is None:
            return None
        
        # Finalize encounter
        self.current_encounter.end_time = time.time()
        self.current_encounter.duration = self.current_encounter.end_time - self.current_encounter.start_time
        
        # Move to history
        self.encounter_history.append(self.current_encounter)
        completed = self.current_encounter
        self.current_encounter = None
        
        return completed
    
    def get_top_damage_dealers(self, limit: int = 10) -> List[Tuple[int, DamageStats]]:
        """
        Get top damage dealers from current encounter.
        
        Args:
            limit: Maximum number of results to return
            
        Returns:
            List of (entity_id, damage_stats) tuples sorted by total damage
        """
        if self.current_encounter is None:
            return []
        
        sorted_sources = sorted(
            self.current_encounter.damage_by_source.items(),
            key=lambda x: x[1].total_damage,
            reverse=True
        )
        
        return sorted_sources[:limit]
