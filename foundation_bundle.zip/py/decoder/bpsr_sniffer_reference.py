"""
Simple BPSR packet sniffer and decoder
======================================

This module provides a lean, minimal‑viable implementation of the packet
reassembly and decode logic used by the Blue Protocol: Star Resonance (BPSR)
logging tool written in Rust.  It is designed to run on Python 3 and relies
on only a handful of third party libraries:

* `pydivert` for capturing traffic on Windows via the WinDivert driver (you
  can fall back to a different capture mechanism such as ``scapy`` if
  desired).
* `zstandard` for decompressing compressed fragments (optional but
  recommended).
* `protobuf` for decoding the game’s protobuf messages.  You must compile
  the BPSR protobuf definitions yourself using ``protoc`` and install
  the generated Python module on your system for this step to work.  If
  no decoder is available the raw payload will simply be passed through.

The core logic closely follows the original Rust implementation:

* The sniffer watches all TCP packets on all interfaces (excluding
  loopback) and tries to identify the game server by searching for a
  special signature (``00 63 33 53 42 00``) in small “scene change” or
  login packets.  Once the server is identified the sniffer begins
  reassembling TCP segments belonging to that connection.
* Reassembled streams are length‑prefixed.  Each BPSR frame starts with a
  four byte big‑endian length.  Frames may themselves contain nested
  frames of type ``FrameDown``.
* Only ``Notify`` and ``FrameDown`` fragments are handled.  ``Notify``
  messages carry a method id which maps to a small set of high‑level
  opcodes.  Those opcodes correspond to well known protobuf messages such
  as ``SyncNearEntities``, ``SyncContainerData`` etc.

This script deliberately avoids implementing a full production ready
application.  It contains just enough structure to demonstrate the
reassembly and decode process and is intended to be used as a starting
point for further development.  The class and function names are kept
similar to the Rust code where possible to aid cross‑referencing.

Usage example (offline parsing)::

    # parse an example packet from the README or another source
    from bpsr_sniffer import BPSRPacketProcessor
    hex_str = (
        "0000007800060000127c0000006e00020000000063335342000000000000002d"
        "0a560880840a124e1205080b120102120708641203dbe7671209086f12059d82"
        "8080041205086712011e120a086a1206b695fa98933312130876120f0df62896"
        "c115809937421d5c8fda40120208651205086c1201011a00"
    )
    data = bytes.fromhex(hex_str)
    processor = BPSRPacketProcessor()
    for pkt, payload in processor.process_bytes(data):
        print(pkt, len(payload))

To capture live traffic on Windows you need the WinDivert driver
installed.  ``pydivert`` takes care of loading the driver for you if it
is available.  See the `BPSRSniffer` class for details.

This code is released under the GPL‑3.0 license to mirror the original
project.
"""

from __future__ import annotations

import collections
import struct
import logging
from enum import Enum
from typing import Dict, Iterable, Optional, Tuple, List, Iterator

try:
    import zstandard as zstd  # Optional, used for compressed fragments
except ImportError:  # pragma: no cover
    zstd = None

try:
    # ``pydivert`` provides a pure‑python interface to WinDivert on Windows.
    import pydivert  # type: ignore
except ImportError:  # pragma: no cover
    pydivert = None

try:
    # If the user compiles the game's protobuf definitions they can be
    # imported here.  Fallback to None if unavailable.
    from blueprotobuf import (
        SyncNearEntities,
        SyncContainerData,
        SyncContainerDirtyData,
        SyncServerTime,
        SyncToMeDeltaInfo,
        SyncNearDeltaInfo,
    )  # type: ignore
    HAVE_PROTO = True
except Exception:  # pragma: no cover
    # The messages haven't been generated; decode will return raw bytes
    HAVE_PROTO = False

# Import our compiled trade protobuf modules
try:
    from bpsr_labs.protobuf.zproto import (
        stru_exchange_item_info_pb2,
        stru_exchange_list_request_pb2,
        stru_exchange_lowest_price_request_pb2,
        stru_exchange_buy_item_request_pb2,
        stru_exchange_sell_item_request_pb2,
        stru_exchange_notice_request_pb2,
        enum_e_exchange_item_type_pb2,
    )
    HAVE_TRADE_PROTO = True
except ImportError:  # pragma: no cover
    HAVE_TRADE_PROTO = False

# Import trade-related modules
try:
    from .trade_extractor import TradeDataExtractor
    from .data_models import TradeCenterItem
    HAVE_TRADE_MODULES = True
except ImportError:  # pragma: no cover
    TradeDataExtractor = None
    TradeCenterItem = None
    HAVE_TRADE_MODULES = False

logger = logging.getLogger(__name__)


class FragmentType(Enum):
    """Enumeration of fragment types used within the BPSR protocol."""

    NONE = 0
    CALL = 1
    NOTIFY = 2
    RETURN = 3
    ECHO = 4
    FRAME_UP = 5
    FRAME_DOWN = 6

    @staticmethod
    def from_u16(value: int) -> "FragmentType":
        return {
            0: FragmentType.NONE,
            1: FragmentType.CALL,
            2: FragmentType.NOTIFY,
            3: FragmentType.RETURN,
            4: FragmentType.ECHO,
            5: FragmentType.FRAME_UP,
            6: FragmentType.FRAME_DOWN,
        }.get(value, FragmentType.NONE)


class Pkt(Enum):
    """High level opcodes used by the game.

    Only a small subset of messages are relevant for damage and healing
    statistics.  Unknown values are mapped to ``None``.
    """

    SERVER_CHANGE_INFO = 0  # Not transmitted in Notify frames, internal
    SYNC_NEAR_ENTITIES = 0x00000006
    SYNC_CONTAINER_DATA = 0x00000015
    SYNC_CONTAINER_DIRTY_DATA = 0x00000016
    SYNC_SERVER_TIME = 0x0000002B
    SYNC_TO_ME_DELTA_INFO = 0x0000002E
    SYNC_NEAR_DELTA_INFO = 0x0000002D

    @classmethod
    def from_u32(cls, val: int) -> Optional["Pkt"]:
        try:
            return cls(val)  # type: ignore[arg-type]
        except ValueError:
            return None


class BinaryReader:
    """Helper to read big‑endian data from a bytes object.

    Instances maintain a cursor into an internal buffer.  Note that all
    multibyte values in the BPSR protocol are big‑endian.
    """

    def __init__(self, data: bytes):
        self._buffer = memoryview(data)
        self._pos = 0

    def remaining(self) -> int:
        return len(self._buffer) - self._pos

    def read(self, length: int) -> bytes:
        if self._pos + length > len(self._buffer):
            raise EOFError("unexpected end of buffer")
        b = self._buffer[self._pos : self._pos + length].tobytes()
        self._pos += length
        return b

    def peek_u32(self) -> int:
        if self.remaining() < 4:
            raise EOFError
        return struct.unpack_from(">I", self._buffer, self._pos)[0]

    def read_u16(self) -> int:
        return struct.unpack(">H", self.read(2))[0]

    def read_u32(self) -> int:
        return struct.unpack(">I", self.read(4))[0]

    def read_u64(self) -> int:
        return struct.unpack(">Q", self.read(8))[0]

    def read_remaining(self) -> bytes:
        return self.read(self.remaining())


class TCPReassembler:
    """Simple TCP stream reassembler.

    Maintains an ordered map of sequence numbers to payloads and yields
    contiguous data when possible.  Only one stream is tracked at a time,
    matching the behaviour of the Rust code where the game server is
    identified and then the sniffer begins reassembling that connection.
    """

    def __init__(self) -> None:
        self.cache: Dict[int, bytes] = {}  # seq_num -> payload
        self.next_seq: Optional[int] = None
        self._data = bytearray()

    def clear(self, seq: int) -> None:
        self.cache.clear()
        self.next_seq = seq
        self._data.clear()

    def push(self, seq: int, payload: bytes) -> None:
        if not payload:
            return
        self.cache.setdefault(seq, payload)
        # establish the next expected sequence if unknown
        if self.next_seq is None:
            self.next_seq = seq
        # buffer contiguous segments
        while self.next_seq in self.cache:
            seg = self.cache.pop(self.next_seq)
            self._data.extend(seg)
            self.next_seq = (self.next_seq + len(seg)) & 0xFFFFFFFF

    def pop_frames(self) -> List[bytes]:
        """Extract complete length‑prefixed frames from the buffered data.

        The BPSR protocol prefixes each frame with a 32‑bit big‑endian
        length.  If not enough data is available for a complete frame
        nothing is returned.
        """
        frames: List[bytes] = []
        while len(self._data) >= 4:
            frame_len = struct.unpack(">I", self._data[:4])[0]
            if len(self._data) < frame_len:
                break
            # slice out the complete frame and remove it from buffer
            frame = bytes(self._data[:frame_len])
            del self._data[:frame_len]
            frames.append(frame)
        return frames


class BPSRPacketProcessor:
    """Process assembled BPSR frames into method opcodes and payloads.

    Use this helper to feed length‑prefixed BPSR frames (``bytes``) and
    iterate over the decoded (``Pkt``, ``bytes``) tuples.  Nested
    ``FrameDown`` packets are handled recursively.
    """

    SERVICE_UUID = 0x0000000063335342

    def __init__(self) -> None:
        # optional mapping of opcodes to protobuf decoders
        self.proto_map: Dict[Pkt, Optional[object]] = {}
        if HAVE_PROTO:
            # assign decoders if protobuf definitions are available
            self.proto_map = {
                Pkt.SYNC_NEAR_ENTITIES: SyncNearEntities,
                Pkt.SYNC_CONTAINER_DATA: SyncContainerData,
                Pkt.SYNC_CONTAINER_DIRTY_DATA: SyncContainerDirtyData,
                Pkt.SYNC_SERVER_TIME: SyncServerTime,
                Pkt.SYNC_TO_ME_DELTA_INFO: SyncToMeDeltaInfo,
                Pkt.SYNC_NEAR_DELTA_INFO: SyncNearDeltaInfo,
            }
        
        # Add trade protobuf decoders if available
        if HAVE_TRADE_PROTO:
            trade_decoders = {
                Pkt.EXCHANGE_LIST_REQUEST: stru_exchange_list_request_pb2.ExchangeListRequest,
                Pkt.EXCHANGE_LIST_REPLY: stru_exchange_item_info_pb2.ExchangeItemInfo,  # Will contain ExchangeItemInfo[]
                Pkt.EXCHANGE_PRICE_REQUEST: stru_exchange_lowest_price_request_pb2.ExchangeLowestPriceRequest,
                Pkt.EXCHANGE_BUY_REQUEST: stru_exchange_buy_item_request_pb2.ExchangeBuyItemRequest,
                Pkt.EXCHANGE_SELL_REQUEST: stru_exchange_sell_item_request_pb2.ExchangeSellItemRequest,
                Pkt.EXCHANGE_NOTICE: stru_exchange_notice_request_pb2.ExchangeNoticeRequest,
            }
            self.proto_map.update(trade_decoders)

    def process_frame(self, frame: bytes) -> Iterator[Tuple[Pkt, bytes]]:
        """Yield (opcode, payload) tuples from a single BPSR frame."""
        reader = BinaryReader(frame)
        while reader.remaining() > 0:
            try:
                pkt_len = reader.peek_u32()
            except EOFError:
                break
            if pkt_len < 6 or reader.remaining() < pkt_len:
                # malformed or incomplete
                break
            fragment = BinaryReader(reader.read(pkt_len))
            # skip length field
            fragment.read_u32()
            frag_type_field = fragment.read_u16()
            is_compressed = frag_type_field & 0x8000
            frag_type_id = frag_type_field & 0x7FFF
            frag_type = FragmentType.from_u16(frag_type_id)
            if frag_type == FragmentType.NOTIFY:
                service_uuid = fragment.read_u64()
                stub_id = fragment.read_u32()  # unused in the current code
                method_id = fragment.read_u32()
                if service_uuid != self.SERVICE_UUID:
                    # not the expected service, drop the frame
                    continue
                payload = fragment.read_remaining()
                if is_compressed and zstd:
                    try:
                        payload = zstd.decompress(payload)
                    except Exception:
                        # decompression failed, skip
                        continue
                pkt = Pkt.from_u32(method_id)
                if pkt is not None:
                    yield pkt, payload
            elif frag_type == FragmentType.FRAME_DOWN:
                # nested frame; read server sequence id and recurse
                _server_seq = fragment.read_u32()
                nested = fragment.read_remaining()
                if is_compressed and zstd:
                    try:
                        nested = zstd.decompress(nested)
                    except Exception:
                        continue
                # Recursively process nested frames
                for tup in self.process_frame(nested):
                    yield tup
            else:
                # other fragment types are ignored for now
                # consume the rest of the fragment and move on
                fragment.read_remaining()

    def process_bytes(self, data: bytes) -> Iterator[Tuple[Pkt, bytes]]:
        """Process one or more concatenated BPSR frames from a byte string."""
        frames = []
        reader = BinaryReader(data)
        while reader.remaining() >= 4:
            try:
                frame_len = reader.peek_u32()
            except EOFError:
                break
            if frame_len == 0 or reader.remaining() < frame_len:
                break
            frames.append(reader.read(frame_len))
        for frame in frames:
            yield from self.process_frame(frame)

    def decode_payload(self, pkt: Pkt, payload: bytes) -> object:
        """Decode a raw payload into a protobuf message if possible.

        If no protobuf decoder is available or the decode fails the raw
        bytes are returned unchanged.
        """
        decoder = self.proto_map.get(pkt) if HAVE_PROTO else None
        if decoder is None:
            return payload
        try:
            # All compiled protobuf messages support ``FromString``
            return decoder.FromString(payload)  # type: ignore[attr-defined]
        except Exception as exc:  # pragma: no cover
            logger.warning("Failed to decode %s: %s", pkt, exc)
            return payload


class BPSRSniffer:
    """Live packet sniffer for BPSR using pydivert.

    Instantiate this class and call :meth:`run` to begin capturing
    packets.  Each decoded message is passed to a user supplied
    callback.  See the Rust implementation for reference on how and
    why the logic is structured this way.
    """

    SIGNATURE = b"\x00\x63\x33\x53\x42\x00"  # 00 63 33 53 42 00
    SIGNATURE1 = b"\x00\x00\x00\x62\x00\x03\x00\x00\x00\x01"
    SIGNATURE2 = b"\x00\x00\x00\x00\x0a\x4e"

    def __init__(self, message_callback, trade_callback=None):
        if not pydivert:
            raise ImportError(
                "pydivert is required for live sniffing. Install with: pip install pydivert"
            )
        self._callback = message_callback
        self._trade_callback = trade_callback
        self._known_server: Optional[Tuple[str, int, str, int]] = None
        self._reassembler = TCPReassembler()
        self._processor = BPSRPacketProcessor()
        
        # Initialize trade extractor if available
        if HAVE_TRADE_MODULES and TradeDataExtractor:
            self._trade_extractor = TradeDataExtractor()
        else:
            self._trade_extractor = None

    def _is_scene_change(self, payload: bytes) -> bool:
        """Check if a small packet contains the magic signature used to find
        the game server during scene changes.
        """
        # 5th byte (index 4) must be zero
        if len(payload) < 10 or payload[4] != 0:
            return False
        reader = BinaryReader(payload[10:])
        # Walk through fragments within the TCP payload looking for the
        # signature at offset 5 of the fragment.
        while reader.remaining() >= 4:
            frag_len = reader.read_u32()
            frag_len_minus_hdr = frag_len - 4
            if reader.remaining() < frag_len_minus_hdr:
                break
            frag = reader.read(frag_len_minus_hdr)
            if len(frag) >= 5 + len(self.SIGNATURE):
                if frag[5 : 5 + len(self.SIGNATURE)] == self.SIGNATURE:
                    return True
        return False

    def _is_login_packet(self, payload: bytes) -> bool:
        """Detect a login response packet based on fixed signatures.

        When the user first logs in the server’s address can be
        discovered by looking for a payload length of 98 bytes along
        with two fixed signatures in the header.
        """
        return (
            len(payload) == 98
            and payload.startswith(self.SIGNATURE1)
            and payload[14:20] == self.SIGNATURE2
        )

    def run(self) -> None:
        """Run the sniffer until interrupted.

        Packets belonging to the identified server are reassembled and
        decoded.  Each decoded message is delivered to the callback.
        """
        try:
            with pydivert.WinDivert(
                "tcp and (ip or ipv6)",
                layer=pydivert.Layer.NETWORK,
                flags=pydivert.Flag.SNIFF,
            ) as w:
                logger.info("WinDivert handle opened")
                for packet in w:
                    if getattr(packet, "is_loopback", False):
                        continue
                    self._handle_packet(packet)
        except KeyboardInterrupt:
            logger.info("Stopping sniffer (CtrlC)")


    def _handle_trade_packet(self, pkt: Pkt, payload: bytes) -> None:
        """Handle trade-related packets and extract trade data."""
        if not self._trade_extractor or not HAVE_TRADE_MODULES:
            return
            
        if pkt == Pkt.SYNC_NEAR_DELTA_INFO:
            # Extract trade data from payload using protobuf decoding
            trade_data = self._trade_extractor.extract_trade_data('SYNC_NEAR_DELTA_INFO', payload)
            if trade_data and (trade_data.get('price') or trade_data.get('item_id')):
                # Create TradeCenterItem from extracted data
                try:
                    if TradeCenterItem:
                        item = TradeCenterItem.from_trade_data(trade_data)
                        if self._trade_callback:
                            self._trade_callback(item)
                except Exception as e:
                    logger.warning("Failed to create TradeCenterItem: %s", e)

    def _handle_packet(self, packet) -> None:
        # Ignore non-TCP or empty payload
        if not getattr(packet, "tcp", None):
            return
        tcp_payload = packet.payload  # <-- use transport payload
        if not tcp_payload:
            return

        # Build normalized 2-endpoint key (direction-agnostic)
        ep1 = (packet.src_addr, packet.src_port)
        ep2 = (packet.dst_addr, packet.dst_port)
        flow_key = frozenset((ep1, ep2))

        # 1) Discover/lock server flow
        if self._known_server != flow_key:
            # Look for scene-change or login signatures in *small* payloads
            if self._is_scene_change(tcp_payload) or self._is_login_packet(tcp_payload):
                logger.info("Locking to flow %s <-> %s", ep1, ep2)
                self._known_server = flow_key
                # Reset reassembler from next expected seq
                # Use TCP header's sequence number; pydivert exposes it as packet.tcp.seq_num
                self._reassembler.clear(packet.tcp.seq_num + len(tcp_payload))
                self._callback(Pkt.SERVER_CHANGE_INFO, b"")
            return  # don't process the discovery packet's payload again

        # 2) Reassemble by TCP sequence number & parse frames for the locked flow
        self._reassembler.push(packet.tcp.seq_num, tcp_payload)
        for frame in self._reassembler.pop_frames():
            for pkt, payload in self._processor.process_frame(frame):
                decoded = self._processor.decode_payload(pkt, payload)
                self._callback(pkt, decoded)
                # Handle trade packets
                self._handle_trade_packet(pkt, payload)


def example_usage() -> None:  # pragma: no cover
    """Simple example printing decoded messages from an offline packet."""
    logging.basicConfig(level=logging.INFO)
    # Example hex string representing a nested FrameDown + Notify
    hex_str = (
        "0000007800060000127c0000006e00020000000063335342000000000000002d"
        "0a560880840a124e1205080b120102120708641203dbe7671209086f12059d82"
        "8080041205086712011e120a086a1206b695fa98933312130876120f0df62896"
        "c115809937421d5c8fda40120208651205086c1201011a00"
    )
    data = bytes.fromhex(hex_str)
    processor = BPSRPacketProcessor()
    for pkt, payload in processor.process_bytes(data):
        print(pkt, len(payload))

def _default_logger(jsonl_path: Optional[str] = None, verbose: bool = False):
    import json, time
    def cb(pkt, decoded):
        if pkt == Pkt.SERVER_CHANGE_INFO:
            print("SERVER_CHANGE_INFO")
            return
        # decoded may be bytes (raw) or a protobuf object
        if isinstance(decoded, (bytes, bytearray)):
            length = len(decoded)
            preview = decoded[:64].hex()
        else:
            # protobuf object -> make a tiny dict repr if possible
            length = getattr(decoded, "ByteSize", lambda: 0)()
            preview = str(decoded)[:200]
        line = {
            "t": time.time(),
            "pkt": pkt.name if hasattr(pkt, "name") else str(pkt),
            "len": length,
            "preview": preview,
        }
        if verbose:
            print(f"{line['pkt']} {line['len']}")
        if jsonl_path:
            with open(jsonl_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(line, ensure_ascii=False) + "\n")
    return cb

def main():
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsonl", help="write decoded messages to JSONL file")
    ap.add_argument("--verbose", action="store_true", help="print per-message summary")
    args = ap.parse_args()
    cb = _default_logger(args.jsonl, args.verbose)
    sniffer = BPSRSniffer(cb)
    sniffer.run()

if __name__ == "__main__":  # pragma: no cover
    # example_usage()
    main()