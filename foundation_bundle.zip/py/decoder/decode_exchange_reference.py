from __future__ import annotations
import argparse
import json
import struct
import sys
from io import BytesIO
from typing import Iterator, Tuple, List

import zstandard as zstd
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
from google.protobuf.json_format import MessageToDict

# ---- wire / framing constants ----
ZSTD_MASK = 0x8000
FRAG_MASK = 0x7FFF
FRAG_NOTIFY = 2
FRAG_FRAMEDOWN = 6
ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"  # zstd magic

# ---- descriptor loading & enumeration (upb-safe) ----
def load_factory_and_names(desc_path: str):
    """
    Load a FileDescriptorSet, register in a DescriptorPool,
    and enumerate fully-qualified message names by walking FileDescriptorProtos.
    """
    fds = descriptor_pb2.FileDescriptorSet()
    with open(desc_path, "rb") as f:
        fds.ParseFromString(f.read())

    pool = descriptor_pool.DescriptorPool()
    for fd in fds.file:
        pool.Add(fd)

    names: List[str] = []

    def walk_msgs(pkg: str, file_proto: descriptor_pb2.FileDescriptorProto):
        # top-level messages
        for m in file_proto.message_type:
            fq = f"{pkg}.{m.name}" if pkg else m.name
            names.append(fq)
            # nested types
            stack: List[Tuple[str, descriptor_pb2.DescriptorProto]] = [(fq, m)]
            while stack:
                prefix, node = stack.pop()
                for child in node.nested_type:
                    child_fq = f"{prefix}.{child.name}"
                    names.append(child_fq)
                    stack.append((child_fq, child))

    for fd in fds.file:
        walk_msgs(fd.package, fd)

    return pool, message_factory.MessageFactory(pool), names

# ---- zstd helpers ----
def maybe_decompress(data: bytes, expect_zstd_flag: bool, where: str) -> bytes:
    """
    Only decompress if the buffer looks like a zstd frame.
    Use streaming to handle unknown output sizes safely.
    """
    if not data:
        return data
    looks_zstd = data.startswith(ZSTD_MAGIC)
    if expect_zstd_flag and not looks_zstd:
        # Flag set but no magic – pass through and warn (common in mixed/nested paths)
        print(f"[warn] {where}: zstd flag set, but no zstd magic; passing through (len={len(data)})", file=sys.stderr)
        return data
    if not looks_zstd:
        return data

    dctx = zstd.ZstdDecompressor()
    out = []
    with dctx.stream_reader(BytesIO(data)) as r:
        while True:
            chunk = r.read(131072)
            if not chunk:
                break
            out.append(chunk)
    return b"".join(out)

# ---- frame iterator ----
def iter_frames(buf: bytes) -> Iterator[Tuple[int, int, int, bytes]]:
    """
    Yields (service_uid, stub_id, method_id, payload_bytes).
    Handles nested FrameDown and conditional zstd.
    """
    f = BytesIO(buf)
    i = 0
    while True:
        hdr = f.read(6)
        if len(hdr) < 6:
            break
        be_len, pkt_type = struct.unpack(">IH", hdr)
        body = f.read(be_len - 6)
        if len(body) < be_len - 6:
            print(f"[warn] short read at frame #{i}", file=sys.stderr)
            break

        is_zstd = (pkt_type & ZSTD_MASK) != 0
        frag = pkt_type & FRAG_MASK

        if frag == FRAG_NOTIFY:
            if len(body) < 16:
                print(f"[warn] notify too short at frame #{i}", file=sys.stderr)
                i += 1
                continue
            service_uid = int.from_bytes(body[:8], "big")
            stub_id = int.from_bytes(body[8:12], "big")
            method_id = int.from_bytes(body[12:16], "big")
            payload = body[16:]
            payload = maybe_decompress(payload, is_zstd, f"notify#{i}")
            yield service_uid, stub_id, method_id, payload

        elif frag == FRAG_FRAMEDOWN:
            nested = maybe_decompress(body, is_zstd, f"framedown#{i}")
            # recurse (nested buffer may contain multiple framed packets)
            for x in iter_frames(nested):
                yield x
        # else: ignore other fragment types

        i += 1

# ---- main decode ----
def decode_exchange(bin_path: str, desc_path: str, out_path: str, discover_pattern: str):
    pool, factory, all_names = load_factory_and_names(desc_path)

    # Build candidate list from descriptor (no private APIs, works on upb runtime)
    patterns = [p.strip() for p in discover_pattern.split(",") if p.strip()]
    def wants(n: str) -> bool:
        return any(p in n for p in patterns)
    exchange_candidates = [n for n in all_names if wants(n)]

    def decode(full_name: str, payload: bytes):
        desc = pool.FindMessageTypeByName(full_name)
        cls = factory.GetPrototype(desc)
        m = cls()
        m.MergeFromString(payload)
        return m

    with open(bin_path, "rb") as f:
        blob = f.read()

    out = open(out_path, "w", encoding="utf-8")
    decoded = 0

    for service_uid, stub_id, method_id, payload in iter_frames(blob):
        matched = False
        for tname in exchange_candidates:
            try:
                msg = decode(tname, payload)
                ser = msg.SerializeToString()
                # light sanity: lengths within 10% or <=8 bytes
                if abs(len(ser) - len(payload)) <= max(8, len(payload) // 10):
                    out.write(json.dumps({
                        "service_uid": f"0x{service_uid:016x}",
                        "stub_id": stub_id,
                        "method_id": method_id,
                        "message_type": tname,
                        "data": MessageToDict(msg, preserving_proto_field_name=True)
                    }, ensure_ascii=False) + "\n")
                    decoded += 1
                    matched = True
                    break
            except Exception:
                # try next candidate
                continue

        if not matched:
            out.write(json.dumps({
                "service_uid": f"0x{service_uid:016x}",
                "stub_id": stub_id,
                "method_id": method_id,
                "message_type": None,
                "data_hex": payload.hex()
            }) + "\n")

    out.close()
    print(f"Wrote {out_path} (decoded {decoded} messages)")
    if decoded == 0:
        print("[note] no Exchange messages matched – confirm capture scope & patterns", file=sys.stderr)

# ---- cli ----
def main():
    ap = argparse.ArgumentParser(description="Decode BPSR Exchange/TradeCenter payloads using a descriptor.pb")
    ap.add_argument("--bin", required=True, help="reassembled stream file (e.g., s2c_training_dummy_full.bin)")
    ap.add_argument("--desc", required=True, help="schema_bundle/descriptor_tradecenter.pb")
    ap.add_argument("--out", default="decoded_exchange.jsonl", help="output JSONL")
    ap.add_argument(
        "--discover",
        default="Exchange,GetExchangeItem,LowestPrice",
        help="comma-separated substrings to select candidate message names from descriptor"
    )
    args = ap.parse_args()
    decode_exchange(args.bin, args.desc, args.out, args.discover)

if __name__ == "__main__":
    main()
