"""
BPSR Frame Parsing and TCP Reassembly
=====================================

This module provides utilities for parsing BPSR packet frames from TCP streams.
It handles the length-prefixed framing, zstd decompression, and RPC fragment
extraction that precedes protobuf decoding.

Key functions:
- parse_frame_header: Extract length, packet_type, service_uid, etc.
- decompress_payload: Handle zstd decompression if needed
- extract_fragments: Parse RPC fragments from frame payload
"""

from __future__ import annotations

import struct
import logging
from typing import Iterator, Tuple, Optional

try:
    import zstandard as zstd
    HAVE_ZSTD = True
except ImportError:
    HAVE_ZSTD = False
    zstd = None

# Frame constants
ZSTD_MASK = 0x8000
FRAG_MASK = 0x7FFF
FRAG_NOTIFY = 2
FRAG_FRAMEDOWN = 6
ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"

# Service UIDs
COMBAT_SERVICE_UID = 0x0000000063335342

logger = logging.getLogger(__name__)


def parse_frame_header(data: bytes) -> Tuple[int, int, int, int, int, bytes]:
    """
    Parse BPSR frame header and return components.
    
    Returns:
        (frag_len, packet_type, service_uid, stub_id, method_id, payload)
    """
    if len(data) < 22:
        raise ValueError("Frame too short for header")
    
    # Parse header fields
    frag_len = struct.unpack('>I', data[0:4])[0]
    packet_type = struct.unpack('>H', data[4:6])[0]
    service_uid = struct.unpack('>Q', data[6:14])[0]
    stub_id = struct.unpack('>I', data[14:18])[0]
    method_id = struct.unpack('>I', data[18:22])[0]
    payload = data[22:]
    
    return frag_len, packet_type, service_uid, stub_id, method_id, payload


def decompress_payload(payload: bytes, is_compressed: bool) -> bytes:
    """
    Decompress payload if it's zstd-compressed.
    
    Args:
        payload: Raw payload bytes
        is_compressed: Whether payload is zstd-compressed
        
    Returns:
        Decompressed payload bytes
    """
    if not is_compressed:
        return payload
    
    if not HAVE_ZSTD:
        logger.warning("zstd compression detected but zstandard library not available")
        return payload
    
    try:
        dctx = zstd.ZstdDecompressor()
        return dctx.decompress(payload)
    except Exception as e:
        logger.error(f"Failed to decompress payload: {e}")
        return payload


def extract_fragments(data: bytes) -> Iterator[Tuple[int, int, int, int, bytes]]:
    """
    Extract RPC fragments from frame data.
    
    Yields:
        (service_uid, stub_id, method_id, frag_type, payload)
    """
    offset = 0
    while offset < len(data):
        if offset + 22 > len(data):
            break
            
        frag_len, packet_type, service_uid, stub_id, method_id, payload = parse_frame_header(data[offset:])
        
        # Check if compressed
        is_compressed = (packet_type & ZSTD_MASK) != 0
        frag_type = packet_type & FRAG_MASK
        
        # Decompress if needed
        if is_compressed:
            payload = decompress_payload(payload, True)
        
        yield service_uid, stub_id, method_id, frag_type, payload
        
        # Move to next fragment
        offset += 22 + len(payload)


def is_combat_packet(service_uid: int) -> bool:
    """Check if packet belongs to combat service."""
    return service_uid == COMBAT_SERVICE_UID
