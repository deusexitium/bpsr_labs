"""
BPSR Combat Decoder Package
===========================

This package provides utilities for decoding Blue Protocol: Star Resonance (BPSR)
combat packets from TCP streams. It includes frame parsing, protobuf decoding,
and combat-specific message processing.

Key modules:
- framing: TCP reassembly and frame parsing
- combat_decode: Combat message decoding
- combat_reduce: DPS/damage aggregation
- codec_tests: Unit tests for the decoder
"""

__version__ = "0.1.0"
__author__ = "BPSR Labs"
