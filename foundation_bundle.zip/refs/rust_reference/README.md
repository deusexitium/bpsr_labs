Perfect. Here’s the **final expanded README.md** with a clean, visual end-to-end dataflow section added at the bottom — modeled on both the original repo’s architecture and the verified breakdowns you’ve gathered.

---

# **BPSR Packet Sniffing References**

This directory contains reference materials, diagrams, and annotated source breakdowns used to understand how **Blue Protocol: Star Resonance (BPSR)** handles its network packets, RPC framing, and protobuf decoding.

> ⚠️ **Note:** This document was built from both reverse-engineering notes and secondary sources (including AI-assisted code summaries). Please treat it as an informed reference, not canonical truth. Validation against live packet captures is recommended.

---

## 🧩 **message.txt — Example Protobuf Dump**

Raw protobuf-decoded snapshot shared by **@winj** showing a live **entity-sync** payload captured through WinDivert.
It confirms successful TCP reassembly and protobuf mapping from the **SRData** schemas.

Contents include:

* Character metadata (`CharId`, `AccountId`, `CharBase`)
* Entity sync and container updates
* Server-time synchronization fields

> 💡 Use as a ground-truth reference to validate your decoding pipeline and `.proto` alignment.

---

## 🧱 **bpsr_packet_structure.png — “Scuffed but How the Packets Work”**

Visual breakdown of how BPSR TCP payloads are framed before protobuf decoding.
Created in **Noteely** during early discovery.

It demonstrates:

* Offset mapping of scene-change and login payloads
* The **`0x006333534200`** server signature (“c3S42”)
* Layer separation between **TCP frame**, **fragment header**, and **protobuf payload**

### **Structure Overview**

| Layer                       | Description                                          |
| --------------------------- | ---------------------------------------------------- |
| **TCP Payload (no header)** | Base data buffer captured post-reassembly            |
| **Fragment Header**         | Length, type, service UID, stub ID, method ID        |
| **Fragment Payload**        | Inner protobuf message (zstd-compressed if flag set) |

> 💡 The image serves as a cheat-sheet for identifying where reassembly stops and protobuf decoding begins.

## ⚙️ **Rust Source Breakdown (bpsr-logs2)**

The following files outline the packet-sniffing pipeline implemented in Rust.

### **main.rs**

Entry point of the Tauri app.
Initializes logging and calls into `lib.rs`.

### **lib.rs**

Registers all **Tauri commands** and initializes the **WinDivert** driver.
Also sets up logging (`setup_logs`) and single-instance handling.
Defines command bindings like:

* `toggle_pause_encounter`
* `hard_reset`
* `get_dps_player_window`
* `get_heal_skill_window`

### **live_main.rs**

Acts as the bridge between the packet processor and UI.
Receives parsed protobuf payloads via async channels and dispatches them to handler functions such as:

* `process_sync_near_entities`
* `process_sync_container_data`
* `process_aoi_sync_delta`

Handles **damage/heal aggregation**, encounter resets, and timing.

### **packet_capture.rs**

Responsible for:

* Opening a **WinDivert** handle with filter `!loopback && ip && tcp`
* Capturing **IPv4 TCP packets**
* Using **heuristics** to identify the **game server** connection:

  * Scene change: 5th byte == 0, contains `0x006333534200`
  * Login: 98-byte payload with same signature
* Performing **TCP reassembly** via `TCPReassembler`
* Forwarding contiguous frames to `packet_process.rs`

### **packet_process.rs**

Core **frame parser**:

* Reads **BE32 length + packet_type (u16)**
* Extracts and unwraps **RPC fragments**
* Applies **zstd decompression** if the high bit of `packet_type` == 1
* Reads fields:

  * `service_uid (8 bytes)`
  * `stub_id (4 bytes)`
  * `method_id (4 bytes)`
  * `frag_payload (var-len protobuf)`
* Currently filters only:

  ```rust
  if service_uid != 0x0000000063335342 { return; }
  ```

  (limits parsing to combat data)
* Sends `(Pkt, payload)` to `live_main` for protobuf decoding

### **opcodes.rs** *(referenced indirectly)*

Maps `method_id` values to known **Pkt** enums such as:
`SyncNearEntities`, `SyncContainerData`, `SyncNearDeltaInfo`, etc.
Defines the fragment types:
`None, Call, Notify, Return, Echo, FrameUp, FrameDown`.

---

## 📦 **Packet Types (from Original Dev Notes)**

| **Packet Name**          | **Purpose / Contents**                                                               |
| ------------------------ | ------------------------------------------------------------------------------------ |
| `SyncNearEntities`       | Entities entering/leaving AOI; includes names, ability scores, class, etc.           |
| `SyncContainerData`      | Detailed snapshot of local player (name, ability score, class, guild, housing, etc.) |
| `SyncContainerDirtyData` | Lightweight update with current HP, max HP, name, and class.                         |
| `SyncServerTime`         | Periodic heartbeat with server timestamp.                                            |
| `SyncToMeDeltaInfo`      | Identifies the UID of the local player.                                              |
| `SyncNearDeltaInfo`      | Entity-to-entity action deltas (e.g., “X damages Y” events).                         |

These correspond directly to method IDs in `opcodes.rs` and protobuf definitions in `blueprotobuf-lib`.

---

## 🧮 **RPC Header Reference**

| **Offset** | **Size** | **Field**      | **Notes**                                          |
| ---------- | -------- | -------------- | -------------------------------------------------- |
| `0–3`      | 4 B      | `frag_len`     | Total frame length (BE 32-bit)                     |
| `4–5`      | 2 B      | `packet_type`  | High bit = zstd flag; low 15 bits = fragment type  |
| `6–13`     | 8 B      | `service_uid`  | Identifies subsystem (combat = 0x0000000063335342) |
| `14–17`    | 4 B      | `stub_id`      | Stub/handler ID (unused)                           |
| `18–21`    | 4 B      | `method_id`    | Maps to `Pkt` enum / protobuf message              |
| `22+`      | variable | `frag_payload` | Protobuf-encoded body (may be zstd-compressed)     |

> When `frag_type == 6 (FrameDown)`, bytes 6–9 store a sequence ID, and the rest nests additional frames.

---

## 🧭 **End-to-End Packet Pipeline**

```text
┌────────────────┐
│  WinDivert DLL │  ← captures TCP traffic (!loopback && ip && tcp)
└──────┬─────────┘
       │ sniffed packets
       ▼
┌───────────────────┐
│ TCPReassembler    │  ← buffers, orders, emits contiguous slices
└──────┬────────────┘
       │ BE32-prefixed frames
       ▼
┌──────────────────────┐
│ packet_process.rs    │  ← reads length, packet_type, decompresses zstd
│                      │  parses service_uid/stub_id/method_id/payload
└──────┬───────────────┘
       │ (Pkt, raw protobuf payload)
       ▼
┌──────────────────────┐
│ live_main.rs         │  ← decodes protobuf via prost
│                      │  dispatches by Pkt enum
└──────┬───────────────┘
       │ decoded messages
       ▼
┌────────────────────────┐
│ opcodes_process.rs     │  ← updates encounter stats, entities, damage
└──────┬─────────────────┘
       │ aggregated results
       ▼
┌────────────────────────┐
│ Tauri/Svelte UI        │  ← queries via commands (get_dps_player_window)
└────────────────────────┘
```

---

## 📎 **Reference Files**

| File                                                                          | Description                                                 |
| ----------------------------------------------------------------------------- | ----------------------------------------------------------- |
| `message.txt`                                                                 | Example decoded entity sync protobuf dump                   |
| `bpsr_packet_structure.png`                                                   | Diagram explaining TCP/fragment/protobuf nesting            |
| `packet_capture.rs`, `packet_process.rs`, `live_main.rs`, `lib.rs`, `main.rs` | Source files describing packet capture and decoding         |